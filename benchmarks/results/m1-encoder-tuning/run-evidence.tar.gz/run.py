import csv, datetime, fcntl, hashlib, json, os, plistlib, random, re, shutil, statistics, subprocess, time, traceback
from pathlib import Path
D=Path(__file__).resolve().parent; B=Path('/tmp/melder-m1-rerun.uvKgZ3'); P=Path('/tmp/melder-m1-coreml-check.1_60zope'); C=Path('/tmp/melder-cap.M2zC25'); M=json.loads((P/'manifest.json').read_text()); template=(B/'encoding/gpu-p8-b256/config.yaml').read_text(); full={s:Path(re.search(r'    path: (\S*dataset_'+s+'_1000k.csv)',template)[1]) for s in 'ab'}; repo=full['a'].parents[2]; binaries={'stock':B/'meld','cap':C/'target/release/meld'}
ENV={k:v for k,v in os.environ.items() if not k.startswith(('RAYON','OMP','ORT','HF','TOKENIZERS','MELDER_EXPERIMENT_','RUST_LOG'))};ENV.update(M['env'],NO_COLOR='1'); results=[]
def save(name,v):
 p=D/name;tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2));tmp.replace(p)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for buf in iter(lambda:f.read(1048576),b''):h.update(buf)
 return h.hexdigest()
def gpu():
 x=plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg','-a','-r','-c','IOAccelerator','-d','1'],timeout=10));return next(a['PerformanceStatistics']['Device Utilization %'] for a in x if 'PerformanceStatistics' in a)
def epoch(s):return datetime.datetime.fromisoformat(s.rstrip('Z')+'+00:00').timestamp()
def inputs(n):
 if n==1000000:return full
 if n==16000:return {s:P/full[s].name for s in 'ab'}
 out={s:D/f'{s}-{n}.csv' for s in 'ab'}
 for s in 'ab':
  if out[s].exists():continue
  with full[s].open(newline='') as f,out[s].open('w',newline='') as o:
   rd=csv.reader(f);wr=csv.writer(o);wr.writerow(next(rd));k=0
   for i,row in enumerate(rd):
    if i==k*1000000//n:wr.writerow(row);k+=1
   assert i+1==1000000 and k==n
 return out
# Each tuple: device, runtime build, encoder slots, texts per batch, CPU threads per session (0 = build default).
CPU=[('cpu','stock',p,b,0) for p,b in [(4,64),(8,64),(12,64),(8,128),(8,32)]]+[('cpu','cap',p,b,t) for p,b,t in [(4,64,4),(8,64,2),(8,128,2),(12,64,1),(16,64,1)]]
GPU=[('gpu','cap',p,b,t) for p,b,t in [(4,128,2),(8,64,2),(8,128,2),(8,256,2),(12,128,2),(12,256,2),(8,128,1),(8,256,1),(8,256,0),(12,256,0)]]
def do(n,key,stage):
 device,build,pool,batch,threads=key; job=D/(str(len(results)+1)+'-'+stage+'-'+('-'.join(map(str,key))));job.mkdir(); cfg=template
 for s,f in inputs(n).items():
  cfg=cfg.replace(str(full[s]),str(f)); cache=job/f'cache-{s}';cache.mkdir();cfg=re.sub(r'(  '+s+'_cache_dir: ).+',lambda m:m[1]+str(cache),cfg)
 for field,val in [('encoder_device',device),('encoder_pool_size',pool),('encoder_batch_size',batch),('csv_dir_path',job/'out')]: cfg=re.sub(r'(  '+field+r': )[^\n]+',lambda m:m[1]+str(val),cfg)
 cfg=re.sub(r'(?m)^  path: .+/crossmap.csv$', '  path: '+str(job/'crossmap.csv'),cfg);(job/'config.yaml').write_text(cfg)
 env=ENV.copy();
 if threads:env['MELDER_EXPERIMENT_THREADS']=str(threads)
 save('state.json',dict(stage=stage,case=key,n=n,job=str(job),completed=len(results)));print(time.ctime(),stage,n,key,flush=True)
 ticks=[]; idle=[gpu() for _ in range(3)]; start=time.monotonic()
 with (job/'cli.log').open('w') as out:
  p=subprocess.Popen([str(binaries[build]),'run','--verbose','--limit','0','--config',str(job/'config.yaml')],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
  try:
   while p.poll() is None:
    t=time.time();util=gpu(); stat=subprocess.run(['ps','-p',str(p.pid),'-o','%cpu=,rss='],text=True,capture_output=True).stdout.split();
    if len(stat)==2:
     cpu,rss=map(float,stat); ticks.append((t,util,cpu,rss)); assert rss<50*1024**2 and shutil.disk_usage(D).free>15*1024**3,'resource guard'
    assert time.monotonic()-start<(12000 if n==1000000 else 1200),'timeout';time.sleep(3 if n==1000000 else 0.85)
  finally:
   if p.poll() is None:
    p.terminate()
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:p.kill();p.wait()
   (job/'samples.json').write_text(json.dumps(ticks))
 assert p.returncode==0,job
 raw=(job/'cli.log').read_text(); assert 'Throughput:   0 records/sec' in raw and ('GPU encoding enabled: CoreML' in raw)==(device=='gpu');
 if build=='cap':assert re.findall(r'TEST_SESSION_INTRA_THREADS=(\d+)',raw)==[str(threads or 20)]*pool
 bounds={};phases={}
 for line in raw.splitlines():
  if 'building combined embedding index' in line or 'combined embedding index built' in line:
   side=re.search(r'side="([AB])"',line)[1]; bounds.setdefault(side,[]).append(epoch(line.split()[0]));
   if 'index built' in line:
    assert int(re.search(r'vecs=(\d+)',line)[1])==n; phases[side]=float(re.search(r'elapsed_s="([\d.]+)"',line)[1])
 assert sorted(phases)==['A','B'] and all(len(v)==2 for v in bounds.values()); measured=[s for s in ticks if any(lo<=s[0]<=hi for lo,hi in bounds.values())];assert measured
 tot=sum(phases.values());r=dict(stage=stage,n=n,key=key,phases=phases,rate=2*n/tot,seconds=tot,gpu_mean=statistics.mean(s[1] for s in measured),gpu_max=max(s[1] for s in measured),gpu_active=sum(s[1]>0 for s in measured),samples=len(measured),cpu_mean=statistics.mean(s[2] for s in measured),idle=idle,job=job.name);assert device!='gpu' or r['gpu_active']>0,'no sampled GPU activity';results.append(r); save('results.json',results);print(round(r['rate'],1),flush=True)
 return r
try:
 with (B/'measurement.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX); print(time.ctime(),'sync wait 120s',flush=True);time.sleep(120)
  for s in 'ab':
   info=M['inputs'][full[s].name]; assert sha(full[s])==info['original_sha256'] and sha(P/full[s].name)==info['sample_sha256']
  assert sha(Path(ENV['ORT_DYLIB_PATH']))==M['ort_sha256'];save('manifest.json',dict(binary_sha={k:sha(v) for k,v in binaries.items()},fixture=M,CPU=CPU,GPU=GPU,medium_sha={s:sha(f) for s,f in inputs(64000).items()}))
  rng=random.Random(729); schedule=CPU+GPU;rng.shuffle(schedule)
  for key in schedule:do(16000,key,'screen')
  def best(stage,dev,count):
   keys={r['key'] for r in results if r['stage']==stage and r['key'][0]==dev};return sorted(keys,key=lambda k:statistics.median(r['rate'] for r in results if r['stage']==stage and r['key']==k),reverse=True)[:count]
  finalists=best('screen','cpu',2)+best('screen','gpu',2);rng.shuffle(finalists)
  for order in (finalists,finalists[::-1]):
   for key in order:do(64000,key,'confirm')
  winners=best('confirm','cpu',1)+best('confirm','gpu',1);save('winners.json',winners)
  for key in winners:do(1000000,key,'full')
  save('state.json',dict(stage='complete',completed=len(results)));(D/'exit').write_text('0\n')
except BaseException:
 traceback.print_exc();(D/'exit').write_text('1\n');raise
